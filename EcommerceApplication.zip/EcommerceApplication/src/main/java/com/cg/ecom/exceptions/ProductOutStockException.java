package com.cg.ecom.exceptions;

public class ProductOutStockException extends RuntimeException
{

	public ProductOutStockException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductOutStockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
