package com.cg.ecom.exceptions;

public class CartIdAlreadyExistsException extends RuntimeException {

	public CartIdAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CartIdAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
